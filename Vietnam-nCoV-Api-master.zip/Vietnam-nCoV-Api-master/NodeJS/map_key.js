/**
 * THIS IS DEFAULT. SHOUNDN'T CHANGE ANYTHING
 */
module.exports = [
    {
        key: "01",
        name: "Hà Nội"
    },
    {
        key: "02",
        name: "Hà Giang"
    },
    {
        key: "04",
        name: "Cao Bằng"
    },
    {
        key: "08",
        name: "Tuyên Quang"
    },
    {
        key: "10",
        name: "Lào Cai"
    },
    {
        key: "11",
        name: "Điện Biên"
    },
    {
        key: "12",
        name: "Lai Châu"
    },
    {
        key: "14",
        name: "Sơn La"
    },
    {
        key: "15",
        name: "Yên Bái"
    },
    {
        key: "17",
        name: "Hòa Bình"
    },
    {
        key: "19",
        name: "Thái Nguyên"
    },
    {
        key: "20",
        name: "Lạng Sơn"
    },
    {
        key: "22",
        name: "Quảng Ninh"
    },
    {
        key: "24",
        name: "Bắc Giang"
    },
    {
        key: "25",
        name: "Phú Thọ"
    },
    {
        key: "26",
        name: "Vinh Phuc"
    },
    {
        key: "27",
        name: "Bắc Ninh"
    },
    {
        key: "30",
        name: "Hải Dương"
    },
    {
        key: "31",
        name: "Hải Phòng"
    },
    {
        key: "33",
        name: "Hưng Yên"
    },
    {
        key: "34",
        name: "Thái Bình"
    },
    {
        key: "35",
        name: "Hà Nam"
    },
    {
        key: "36",
        name: "Nam Định"
    },
    {
        key: "37",
        name: "Ninh Bình"
    },
    {
        key: "38",
        name: "Thanh Hóa"
    },
    {
        key: "40",
        name: "Nghệ An"
    },
    {
        key: "42",
        name: "Hà Tình"
    },
    {
        key: "44",
        name: "Quảng Bình"
    },
    {
        key: "45",
        name: "Quảng Trị"
    },
    {
        key: "46",
        name: "Thừa Thiên Huế"
    },
    {
        key: "48",
        name: "Đà Nẵng"
    },
    {
        key: "49",
        name: "Quảng Nam"
    },
    {
        key: "51",
        name: "Quảng Ngãi"
    },
    {
        key: "52",
        name: "Bình Định"
    },
    {
        key: "54",
        name: "Phú Yên"
    },
    {
        key: "56",
        name: "Khánh Hòa"
    },
    {
        key: "58",
        name: "Ninh Thuận"
    },
    {
        key: "60",
        name: "Bình Thuận"
    },
    {
        key: "62",
        name: "Kon Tum"
    },
    {
        key: "64",
        name: "Gia Lai"
    },
    {
        key: "66",
        name: "Đắk Lắk"
    },
    {
        key: "67",
        name: "Đắk Nông"
    },
    {
        key: "68",
        name: "Lâm Đồng"
    },
    {
        key: "70",
        name: "Bình Phước"
    },
    {
        key: "72",
        name: "Tây Ninh"
    },
    {
        key: "74",
        name: "Bình Dương"
    },
    {
        key: "77",
        name: "Bà Rịa - Vũng Tàu"
    },
    {
        key: "79",
        name: "Hồ Chí Minh"
    },
    {
        key: "80",
        name: "Long An"
    },
    {
        key: "81",
        name: "Tiền Giang"
    },
    {
        key: "83",
        name: "Bến Tre"
    },
    {
        key: "84",
        name: "Trà Vinh"
    },
    {
        key: "85",
        name: "Vĩnh Long"
    },
    {
        key: "87",
        name: "Đồng Tháp"
    },
    {
        key: "89",
        name: "An Giang"
    },
    {
        key: "91",
        name: "Kiên Giang"
    },
    {
        key: "92",
        name: "Cần Thơ"
    },
    {
        key: "93",
        name: "Hậu Giang"
    },
    {
        key: "94",
        name: "Sóc Trăng"
    },
    {
        key: "95",
        name: "Bạc Liêu"
    },
    {
        key: "96",
        name: "Cà Mau"
    }
]
